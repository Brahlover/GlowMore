# Glowmore

Glowmore is a white-label AI lead qualification and reporting copilot for agencies.

## Core USP
**Attribution-aware AI strategist**

Glowmore helps agencies:
- reconcile conflicting platform numbers
- explain why attribution numbers differ
- generate ranked next-step recommendations
- produce client-ready performance narratives
- score and route leads automatically

## Stack
- **Frontend:** HTML, CSS, JavaScript
- **Backend:** Java 21, Spring Boot
- **Database:** H2 for local development (free), PostgreSQL later
- **AI Strategy Layer:** rule-based MVP, pluggable for future local/free LLM support

## Project Structure
```text
Glowmore/
├── README.md
├── .gitignore
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/glowmore/copilot/
│       └── resources/
├── frontend/
│   ├── index.html
│   ├── dashboard.html
│   ├── client.html
│   ├── report.html
│   ├── styles.css
│   └── app.js
└── docs/
    ├── api-spec.md
    └── sample-csvs/
```

## MVP Features in This Starter
- client workspace creation
- CSV upload endpoint scaffold
- attribution analysis endpoint
- ranked recommendation generation
- client-ready report generation
- static frontend dashboard pages

## How to Run the Backend
### Prerequisites
- Java 21+
- Maven 3.9+

### Start
```bash
cd backend
mvn spring-boot:run
```

Backend runs on:
```text
http://localhost:8080
```

## How to Run the Frontend
You can open the HTML files directly in a browser, but using a local server is better.

### Option 1: VS Code Live Server
Open `frontend/` and run with Live Server.

### Option 2: Python simple server
```bash
cd frontend
python -m http.server 5500
```

Frontend runs on:
```text
http://localhost:5500
```

## Example Local Workflow
1. Start the backend
2. Open the frontend
3. Create a client from the dashboard
4. Upload CSVs in the client workspace
5. Run analysis
6. Open the report page

## Suggested Git Branches
```text
main
dev
feature/frontend-shell
feature/csv-import
feature/reconciliation-engine
feature/lead-scoring
feature/report-generator
```

## Suggested First Git Commits
```bash
git init
git add .
git commit -m "Initial Glowmore MVP scaffold"

git checkout -b dev
git checkout -b feature/frontend-shell
```

## Sample GitHub Repo Name
```text
glowmore
```

## Next Recommended Build Steps
1. finish CSV normalization for Meta/Google/Shopify templates
2. persist uploads and analysis history
3. add lead scoring weights in database or config
4. add report export (PDF/Markdown)
5. add white-label settings per agency/client
6. add local LLM option later (optional)

## Notes
This starter is intentionally designed to work as a **free MVP** without requiring any paid AI subscription.
