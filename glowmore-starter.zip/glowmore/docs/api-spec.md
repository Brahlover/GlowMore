# Glowmore API Spec (MVP)

## Base URL
```text
http://localhost:8080/api
```

## Endpoints

### Health
- `GET /health`

### Clients
- `GET /clients`
- `POST /clients`
- `GET /clients/{id}`

### Uploads
- `POST /uploads/{clientId}`
  - multipart form-data
  - file
  - source (`META`, `GOOGLE`, `SHOPIFY`, `CRM`)

### Analysis
- `POST /analysis/{clientId}?start=2026-03-01&end=2026-03-31`

### Reports
- `POST /reports/{clientId}/generate?tone=CONSULTATIVE`
- `GET /reports/{clientId}/latest`
