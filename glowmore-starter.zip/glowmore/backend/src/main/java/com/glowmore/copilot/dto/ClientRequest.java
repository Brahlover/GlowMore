package com.glowmore.copilot.dto;

import com.glowmore.copilot.model.ToneProfile;
import jakarta.validation.constraints.NotBlank;

public class ClientRequest {
    @NotBlank
    private String name;
    private ToneProfile toneProfile = ToneProfile.CONSULTATIVE;
    private String industry;
    private String timezone;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public ToneProfile getToneProfile() { return toneProfile; }
    public void setToneProfile(ToneProfile toneProfile) { this.toneProfile = toneProfile; }
    public String getIndustry() { return industry; }
    public void setIndustry(String industry) { this.industry = industry; }
    public String getTimezone() { return timezone; }
    public void setTimezone(String timezone) { this.timezone = timezone; }
}
