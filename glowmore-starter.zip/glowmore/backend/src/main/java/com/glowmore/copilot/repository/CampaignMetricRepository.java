package com.glowmore.copilot.repository;

import com.glowmore.copilot.model.CampaignMetric;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.SourcePlatform;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CampaignMetricRepository extends JpaRepository<CampaignMetric, Long> {
    List<CampaignMetric> findByClientAndDateBetween(Client client, LocalDate start, LocalDate end);
    List<CampaignMetric> findByClientAndSourceAndDateBetween(Client client, SourcePlatform source, LocalDate start, LocalDate end);
}
