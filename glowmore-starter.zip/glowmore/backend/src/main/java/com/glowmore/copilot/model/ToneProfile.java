package com.glowmore.copilot.model;

public enum ToneProfile {
    FORMAL,
    CONSULTATIVE,
    BRIEF
}
