package com.glowmore.copilot.service;

import com.glowmore.copilot.dto.ClientRequest;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.repository.ClientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClientService {
    private final ClientRepository clientRepository;

    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    public List<Client> getAll() {
        return clientRepository.findAll();
    }

    public Client getById(Long id) {
        return clientRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Client not found: " + id));
    }

    public Client create(ClientRequest request) {
        Client client = new Client();
        client.setName(request.getName());
        client.setToneProfile(request.getToneProfile());
        client.setIndustry(request.getIndustry());
        client.setTimezone(request.getTimezone());
        return clientRepository.save(client);
    }
}
