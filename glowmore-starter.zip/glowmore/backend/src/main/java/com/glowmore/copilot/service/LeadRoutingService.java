package com.glowmore.copilot.service;

import com.glowmore.copilot.model.Lead;
import com.glowmore.copilot.model.RoutingStatus;
import org.springframework.stereotype.Service;

@Service
public class LeadRoutingService {
    public void route(Lead lead) {
        int score = lead.getScore() == null ? 0 : lead.getScore();

        if (score >= 80) {
            lead.setRoutingStatus(RoutingStatus.SENIOR_QUEUE);
            lead.setAssignedTo("Senior Closer");
        } else if (score >= 50) {
            lead.setRoutingStatus(RoutingStatus.STANDARD_QUEUE);
            lead.setAssignedTo("Sales Rep");
        } else {
            lead.setRoutingStatus(RoutingStatus.NURTURE_QUEUE);
            lead.setAssignedTo("Nurture Sequence");
        }
    }
}
