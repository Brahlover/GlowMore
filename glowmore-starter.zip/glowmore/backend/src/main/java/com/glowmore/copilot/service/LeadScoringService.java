package com.glowmore.copilot.service;

import com.glowmore.copilot.model.Lead;
import com.glowmore.copilot.model.SourcePlatform;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class LeadScoringService {
    public int score(Lead lead) {
        int score = 0;

        if (lead.getServiceInterest() != null && lead.getServiceInterest().toLowerCase().contains("enterprise")) {
            score += 30;
        }
        if (lead.getEstimatedBudget() != null && lead.getEstimatedBudget().compareTo(new BigDecimal("3000")) > 0) {
            score += 20;
        }
        if (lead.getSource() == SourcePlatform.GOOGLE) {
            score += 15;
        }
        if (hasValue(lead.getPhone()) && hasValue(lead.getCompany())) {
            score += 10;
        }
        if (!hasValue(lead.getServiceInterest())) {
            score -= 10;
        }

        return Math.max(0, Math.min(score, 100));
    }

    private boolean hasValue(String value) {
        return value != null && !value.isBlank();
    }
}
