package com.glowmore.copilot.service;

import com.glowmore.copilot.dto.AnalysisResponse;
import com.glowmore.copilot.dto.ReportDto;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.Report;
import com.glowmore.copilot.model.ToneProfile;
import com.glowmore.copilot.repository.ReportRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class ReportGenerationService {
    private final ReportRepository reportRepository;
    private final AttributionReconciliationService attributionReconciliationService;

    public ReportGenerationService(ReportRepository reportRepository,
                                   AttributionReconciliationService attributionReconciliationService) {
        this.reportRepository = reportRepository;
        this.attributionReconciliationService = attributionReconciliationService;
    }

    public ReportDto generate(Client client, LocalDate start, LocalDate end, ToneProfile tone) {
        AnalysisResponse analysis = attributionReconciliationService.analyze(client, start, end);
        String summary = buildSummary(tone, analysis);
        String body = buildBody(analysis);

        Report report = new Report();
        report.setClient(client);
        report.setPeriodStart(start);
        report.setPeriodEnd(end);
        report.setToneProfile(tone);
        report.setExecutiveSummary(summary);
        report.setBodyMarkdown(body);
        reportRepository.save(report);

        return new ReportDto(summary, body, tone.name());
    }

    public ReportDto latest(Client client) {
        return reportRepository.findTopByClientOrderByCreatedAtDesc(client)
                .map(r -> new ReportDto(r.getExecutiveSummary(), r.getBodyMarkdown(), r.getToneProfile().name()))
                .orElse(new ReportDto("No report generated yet.", "Generate a report to see output.", client.getToneProfile().name()));
    }

    private String buildSummary(ToneProfile tone, AnalysisResponse analysis) {
        return switch (tone) {
            case FORMAL -> "During this period, platform-reported conversions varied across channels. After reconciliation, the highest-confidence actions are to improve tracking consistency, reduce weak spend, and scale the most efficient campaign.";
            case BRIEF -> "Numbers differ across platforms. Best next steps: cut weak spend, scale efficient campaigns, and fix tracking gaps.";
            case CONSULTATIVE -> "The numbers do not fully match across platforms, which is common when attribution windows and overlap differ. The best move now is to fix measurement confidence, trim weak spend, and lean into the campaign showing the strongest efficiency.";
        };
    }

    private String buildBody(AnalysisResponse analysis) {
        StringBuilder sb = new StringBuilder();
        sb.append("## Reconciliation Summary
");
        sb.append("- Meta conversions: ").append(analysis.getMetaConversions()).append("
");
        sb.append("- Google conversions: ").append(analysis.getGoogleConversions()).append("
");
        sb.append("- Shopify/store orders: ").append(analysis.getShopifyOrders()).append("
");
        sb.append("- Confidence: ").append(analysis.getConfidenceScore()).append("

");
        sb.append("## Why the numbers differ
");
        sb.append(analysis.getExplanation()).append("

");
        sb.append("## Recommended actions
");
        analysis.getRecommendations().forEach(r -> sb.append(r.getPriorityRank()).append(") ").append(r.getTitle()).append(" — ").append(r.getRationale()).append("
"));
        return sb.toString();
    }
}
