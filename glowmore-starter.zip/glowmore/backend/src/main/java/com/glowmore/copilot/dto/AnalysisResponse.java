package com.glowmore.copilot.dto;

import java.util.List;

public class AnalysisResponse {
    private int metaConversions;
    private int googleConversions;
    private int shopifyOrders;
    private String confidenceScore;
    private String explanation;
    private List<RecommendationDto> recommendations;

    public AnalysisResponse(int metaConversions, int googleConversions, int shopifyOrders,
                            String confidenceScore, String explanation,
                            List<RecommendationDto> recommendations) {
        this.metaConversions = metaConversions;
        this.googleConversions = googleConversions;
        this.shopifyOrders = shopifyOrders;
        this.confidenceScore = confidenceScore;
        this.explanation = explanation;
        this.recommendations = recommendations;
    }

    public int getMetaConversions() { return metaConversions; }
    public int getGoogleConversions() { return googleConversions; }
    public int getShopifyOrders() { return shopifyOrders; }
    public String getConfidenceScore() { return confidenceScore; }
    public String getExplanation() { return explanation; }
    public List<RecommendationDto> getRecommendations() { return recommendations; }
}
