package com.glowmore.copilot.controller;

import com.glowmore.copilot.dto.AnalysisResponse;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.service.AttributionReconciliationService;
import com.glowmore.copilot.service.ClientService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/analysis")
public class AnalysisController {
    private final ClientService clientService;
    private final AttributionReconciliationService attributionReconciliationService;

    public AnalysisController(ClientService clientService,
                              AttributionReconciliationService attributionReconciliationService) {
        this.clientService = clientService;
        this.attributionReconciliationService = attributionReconciliationService;
    }

    @PostMapping("/{clientId}")
    public AnalysisResponse analyze(@PathVariable Long clientId,
                                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
                                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {
        Client client = clientService.getById(clientId);
        return attributionReconciliationService.analyze(client, start, end);
    }
}
