package com.glowmore.copilot.service;

import com.glowmore.copilot.dto.RecommendationDto;
import com.glowmore.copilot.model.CampaignMetric;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.repository.CampaignMetricRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class RecommendationService {
    private final CampaignMetricRepository campaignMetricRepository;

    public RecommendationService(CampaignMetricRepository campaignMetricRepository) {
        this.campaignMetricRepository = campaignMetricRepository;
    }

    public List<RecommendationDto> generate(Client client, LocalDate start, LocalDate end) {
        List<CampaignMetric> metrics = campaignMetricRepository.findByClientAndDateBetween(client, start, end);
        List<RecommendationDto> output = new ArrayList<>();

        metrics.stream()
            .filter(m -> m.getSpend() != null && m.getSpend().compareTo(new BigDecimal("100")) > 0)
            .filter(m -> safeInt(m.getConversions()) <= 2)
            .sorted(Comparator.comparing(CampaignMetric::getSpend).reversed())
            .findFirst()
            .ifPresent(m -> output.add(new RecommendationDto(
                1,
                "Budget Optimization",
                "Pause or reduce budget on " + m.getCampaignName(),
                "Spend is elevated while conversion volume remains below target.",
                "High"
            )));

        metrics.stream()
            .filter(m -> safeInt(m.getConversions()) >= 5)
            .sorted((a, b) -> cpa(a).compareTo(cpa(b)))
            .findFirst()
            .ifPresent(m -> output.add(new RecommendationDto(
                2,
                "Scaling",
                "Increase budget on " + m.getCampaignName() + " by 20%",
                "This campaign is generating comparatively efficient conversions.",
                "High"
            )));

        output.add(new RecommendationDto(
            3,
            "Tracking",
            "Audit UTM and attribution consistency across channels",
            "Conflicting platform claims reduce budget confidence and can distort optimization decisions.",
            "Medium"
        ));

        output.add(new RecommendationDto(
            4,
            "Audience",
            "Create or expand retargeting from high-intent visitors",
            "Returning visitors often convert more efficiently than cold traffic when tracking and messaging are aligned.",
            "Medium"
        ));

        return output;
    }

    private int safeInt(Integer value) {
        return value == null ? 0 : value;
    }

    private BigDecimal cpa(CampaignMetric m) {
        int conversions = Math.max(1, safeInt(m.getConversions()));
        return m.getSpend() == null ? BigDecimal.valueOf(999999) : m.getSpend().divide(BigDecimal.valueOf(conversions), 2, RoundingMode.HALF_UP);
    }
}
