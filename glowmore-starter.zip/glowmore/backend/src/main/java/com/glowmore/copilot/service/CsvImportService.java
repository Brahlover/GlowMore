package com.glowmore.copilot.service;

import com.glowmore.copilot.model.CampaignMetric;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.SourcePlatform;
import com.glowmore.copilot.repository.CampaignMetricRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.time.LocalDate;

@Service
public class CsvImportService {
    private final CampaignMetricRepository campaignMetricRepository;

    public CsvImportService(CampaignMetricRepository campaignMetricRepository) {
        this.campaignMetricRepository = campaignMetricRepository;
    }

    public int importCampaignMetrics(Client client, SourcePlatform source, MultipartFile file) throws IOException {
        int rows = 0;

        try (CSVParser parser = CSVFormat.DEFAULT
                .builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .build()
                .parse(new InputStreamReader(file.getInputStream()))) {

            for (CSVRecord record : parser) {
                CampaignMetric metric = new CampaignMetric();
                metric.setClient(client);
                metric.setSource(source);
                metric.setDate(parseDate(record.get("date")));
                metric.setCampaignName(getValue(record, "campaign_name", defaultCampaignName(source)));
                metric.setSpend(parseDecimal(getValue(record, "spend", "0")));
                metric.setClicks(parseInt(getValue(record, "clicks", "0")));
                metric.setImpressions(parseInt(getValue(record, "impressions", "0")));
                metric.setConversions(parseInt(getValue(record, "conversions", getValue(record, "order_count", "0"))));
                metric.setLeads(parseInt(getValue(record, "leads", "0")));
                metric.setRevenue(parseDecimal(getValue(record, "revenue", "0")));
                campaignMetricRepository.save(metric);
                rows++;
            }
        }

        return rows;
    }

    private String getValue(CSVRecord record, String field, String fallback) {
        try {
            String value = record.get(field);
            return value == null || value.isBlank() ? fallback : value;
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }

    private String defaultCampaignName(SourcePlatform source) {
        return source == SourcePlatform.SHOPIFY ? "Store Orders" : "Unnamed Campaign";
    }

    private LocalDate parseDate(String value) {
        return LocalDate.parse(value.trim());
    }

    private int parseInt(String value) {
        try { return Integer.parseInt(value.trim()); }
        catch (Exception ex) { return 0; }
    }

    private BigDecimal parseDecimal(String value) {
        try { return new BigDecimal(value.trim()); }
        catch (Exception ex) { return BigDecimal.ZERO; }
    }
}
