package com.glowmore.copilot.repository;

import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.Report;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ReportRepository extends JpaRepository<Report, Long> {
    Optional<Report> findTopByClientOrderByCreatedAtDesc(Client client);
}
