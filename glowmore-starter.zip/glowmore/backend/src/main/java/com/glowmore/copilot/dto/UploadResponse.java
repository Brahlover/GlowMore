package com.glowmore.copilot.dto;

public class UploadResponse {
    private String source;
    private String fileName;
    private int rowsImported;
    private String message;

    public UploadResponse(String source, String fileName, int rowsImported, String message) {
        this.source = source;
        this.fileName = fileName;
        this.rowsImported = rowsImported;
        this.message = message;
    }

    public String getSource() { return source; }
    public String getFileName() { return fileName; }
    public int getRowsImported() { return rowsImported; }
    public String getMessage() { return message; }
}
