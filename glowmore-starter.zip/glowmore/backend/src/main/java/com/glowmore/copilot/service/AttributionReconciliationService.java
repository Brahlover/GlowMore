package com.glowmore.copilot.service;

import com.glowmore.copilot.dto.AnalysisResponse;
import com.glowmore.copilot.dto.RecommendationDto;
import com.glowmore.copilot.model.CampaignMetric;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.SourcePlatform;
import com.glowmore.copilot.repository.CampaignMetricRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class AttributionReconciliationService {
    private final CampaignMetricRepository campaignMetricRepository;
    private final RecommendationService recommendationService;

    public AttributionReconciliationService(CampaignMetricRepository campaignMetricRepository,
                                            RecommendationService recommendationService) {
        this.campaignMetricRepository = campaignMetricRepository;
        this.recommendationService = recommendationService;
    }

    public AnalysisResponse analyze(Client client, LocalDate start, LocalDate end) {
        int metaConversions = sumConversions(client, SourcePlatform.META, start, end);
        int googleConversions = sumConversions(client, SourcePlatform.GOOGLE, start, end);
        int shopifyOrders = sumConversions(client, SourcePlatform.SHOPIFY, start, end);

        String confidence = calculateConfidence(metaConversions, googleConversions, shopifyOrders);
        String explanation = buildExplanation(metaConversions, googleConversions, shopifyOrders);
        List<RecommendationDto> recommendations = recommendationService.generate(client, start, end);

        return new AnalysisResponse(metaConversions, googleConversions, shopifyOrders, confidence, explanation, recommendations);
    }

    private int sumConversions(Client client, SourcePlatform source, LocalDate start, LocalDate end) {
        List<CampaignMetric> metrics = campaignMetricRepository.findByClientAndSourceAndDateBetween(client, source, start, end);
        return metrics.stream().mapToInt(m -> m.getConversions() == null ? 0 : m.getConversions()).sum();
    }

    private String calculateConfidence(int meta, int google, int shopify) {
        int claimed = meta + google;
        int delta = Math.abs(claimed - shopify);
        if (delta <= 3) return "High";
        if (delta <= 10) return "Medium";
        return "Low";
    }

    private String buildExplanation(int meta, int google, int shopify) {
        int claimed = meta + google;
        if (claimed == shopify) {
            return "Platform claims and store-reported outcomes are closely aligned for this period.";
        }
        if (claimed > shopify) {
            return "Ad platforms are claiming more conversions than the store reports. Likely causes include attribution window overlap, assisted conversions, and duplicate channel claims.";
        }
        return "Store-reported outcomes exceed platform-reported conversions. Likely causes include unattributed direct traffic, delayed reporting, or missing campaign tracking.";
    }
}
