package com.glowmore.copilot.controller;

import com.glowmore.copilot.dto.ClientRequest;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.service.ClientService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clients")
public class ClientController {
    private final ClientService clientService;

    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    @GetMapping
    public List<Client> getAll() {
        return clientService.getAll();
    }

    @GetMapping("/{id}")
    public Client getById(@PathVariable Long id) {
        return clientService.getById(id);
    }

    @PostMapping
    public Client create(@Valid @RequestBody ClientRequest request) {
        return clientService.create(request);
    }
}
