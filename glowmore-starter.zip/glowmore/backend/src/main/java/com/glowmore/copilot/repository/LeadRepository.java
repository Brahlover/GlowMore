package com.glowmore.copilot.repository;

import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.Lead;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LeadRepository extends JpaRepository<Lead, Long> {
    List<Lead> findByClient(Client client);
}
