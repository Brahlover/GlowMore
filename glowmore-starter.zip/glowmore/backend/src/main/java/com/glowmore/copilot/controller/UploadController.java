package com.glowmore.copilot.controller;

import com.glowmore.copilot.dto.UploadResponse;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.SourcePlatform;
import com.glowmore.copilot.service.ClientService;
import com.glowmore.copilot.service.CsvImportService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/uploads")
public class UploadController {
    private final ClientService clientService;
    private final CsvImportService csvImportService;

    public UploadController(ClientService clientService, CsvImportService csvImportService) {
        this.clientService = clientService;
        this.csvImportService = csvImportService;
    }

    @PostMapping(value = "/{clientId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public UploadResponse upload(@PathVariable Long clientId,
                                 @RequestParam("source") SourcePlatform source,
                                 @RequestParam("file") MultipartFile file) throws IOException {
        Client client = clientService.getById(clientId);
        int rows = csvImportService.importCampaignMetrics(client, source, file);
        return new UploadResponse(source.name(), file.getOriginalFilename(), rows, "Upload processed successfully.");
    }
}
