package com.glowmore.copilot.model;

public enum RoutingStatus {
    SENIOR_QUEUE,
    STANDARD_QUEUE,
    NURTURE_QUEUE,
    UNASSIGNED
}
