package com.glowmore.copilot.dto;

public class RecommendationDto {
    private int priorityRank;
    private String category;
    private String title;
    private String rationale;
    private String expectedImpact;

    public RecommendationDto(int priorityRank, String category, String title, String rationale, String expectedImpact) {
        this.priorityRank = priorityRank;
        this.category = category;
        this.title = title;
        this.rationale = rationale;
        this.expectedImpact = expectedImpact;
    }

    public int getPriorityRank() { return priorityRank; }
    public String getCategory() { return category; }
    public String getTitle() { return title; }
    public String getRationale() { return rationale; }
    public String getExpectedImpact() { return expectedImpact; }
}
