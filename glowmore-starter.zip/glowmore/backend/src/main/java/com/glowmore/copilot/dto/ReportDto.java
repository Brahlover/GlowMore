package com.glowmore.copilot.dto;

public class ReportDto {
    private String executiveSummary;
    private String bodyMarkdown;
    private String toneProfile;

    public ReportDto(String executiveSummary, String bodyMarkdown, String toneProfile) {
        this.executiveSummary = executiveSummary;
        this.bodyMarkdown = bodyMarkdown;
        this.toneProfile = toneProfile;
    }

    public String getExecutiveSummary() { return executiveSummary; }
    public String getBodyMarkdown() { return bodyMarkdown; }
    public String getToneProfile() { return toneProfile; }
}
