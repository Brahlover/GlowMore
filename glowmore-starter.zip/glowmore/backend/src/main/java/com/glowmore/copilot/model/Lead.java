package com.glowmore.copilot.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "leads")
public class Lead {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Client client;

    @Enumerated(EnumType.STRING)
    private SourcePlatform source;

    private String contactName;
    private String email;
    private String phone;
    private String company;
    private String serviceInterest;
    private BigDecimal estimatedBudget = BigDecimal.ZERO;
    private Integer score = 0;

    @Enumerated(EnumType.STRING)
    private RoutingStatus routingStatus = RoutingStatus.UNASSIGNED;

    private String assignedTo;
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Client getClient() { return client; }
    public void setClient(Client client) { this.client = client; }
    public SourcePlatform getSource() { return source; }
    public void setSource(SourcePlatform source) { this.source = source; }
    public String getContactName() { return contactName; }
    public void setContactName(String contactName) { this.contactName = contactName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getServiceInterest() { return serviceInterest; }
    public void setServiceInterest(String serviceInterest) { this.serviceInterest = serviceInterest; }
    public BigDecimal getEstimatedBudget() { return estimatedBudget; }
    public void setEstimatedBudget(BigDecimal estimatedBudget) { this.estimatedBudget = estimatedBudget; }
    public Integer getScore() { return score; }
    public void setScore(Integer score) { this.score = score; }
    public RoutingStatus getRoutingStatus() { return routingStatus; }
    public void setRoutingStatus(RoutingStatus routingStatus) { this.routingStatus = routingStatus; }
    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String assignedTo) { this.assignedTo = assignedTo; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
