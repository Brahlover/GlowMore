package com.glowmore.copilot.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "campaign_metrics")
public class CampaignMetric {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Client client;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SourcePlatform source;

    private String campaignName;
    private LocalDate date;
    private BigDecimal spend = BigDecimal.ZERO;
    private Integer clicks = 0;
    private Integer impressions = 0;
    private Integer leads = 0;
    private Integer conversions = 0;
    private BigDecimal revenue = BigDecimal.ZERO;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Client getClient() { return client; }
    public void setClient(Client client) { this.client = client; }
    public SourcePlatform getSource() { return source; }
    public void setSource(SourcePlatform source) { this.source = source; }
    public String getCampaignName() { return campaignName; }
    public void setCampaignName(String campaignName) { this.campaignName = campaignName; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public BigDecimal getSpend() { return spend; }
    public void setSpend(BigDecimal spend) { this.spend = spend; }
    public Integer getClicks() { return clicks; }
    public void setClicks(Integer clicks) { this.clicks = clicks; }
    public Integer getImpressions() { return impressions; }
    public void setImpressions(Integer impressions) { this.impressions = impressions; }
    public Integer getLeads() { return leads; }
    public void setLeads(Integer leads) { this.leads = leads; }
    public Integer getConversions() { return conversions; }
    public void setConversions(Integer conversions) { this.conversions = conversions; }
    public BigDecimal getRevenue() { return revenue; }
    public void setRevenue(BigDecimal revenue) { this.revenue = revenue; }
}
