package com.glowmore.copilot.repository;

import com.glowmore.copilot.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Long> {
}
