package com.glowmore.copilot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlowmoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(GlowmoreApplication.class, args);
    }
}
