package com.glowmore.copilot.controller;

import com.glowmore.copilot.dto.ReportDto;
import com.glowmore.copilot.model.Client;
import com.glowmore.copilot.model.ToneProfile;
import com.glowmore.copilot.service.ClientService;
import com.glowmore.copilot.service.ReportGenerationService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final ClientService clientService;
    private final ReportGenerationService reportGenerationService;

    public ReportController(ClientService clientService,
                            ReportGenerationService reportGenerationService) {
        this.clientService = clientService;
        this.reportGenerationService = reportGenerationService;
    }

    @PostMapping("/{clientId}/generate")
    public ReportDto generate(@PathVariable Long clientId,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
                              @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end,
                              @RequestParam(defaultValue = "CONSULTATIVE") ToneProfile tone) {
        Client client = clientService.getById(clientId);
        return reportGenerationService.generate(client, start, end, tone);
    }

    @GetMapping("/{clientId}/latest")
    public ReportDto latest(@PathVariable Long clientId) {
        Client client = clientService.getById(clientId);
        return reportGenerationService.latest(client);
    }
}
