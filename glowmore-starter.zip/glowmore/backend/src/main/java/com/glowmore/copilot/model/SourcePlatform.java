package com.glowmore.copilot.model;

public enum SourcePlatform {
    META,
    GOOGLE,
    SHOPIFY,
    CRM
}
