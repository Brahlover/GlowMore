const API_BASE = 'http://localhost:8080/api';

async function checkHealth() {
  const box = document.getElementById('health-result');
  try {
    const res = await fetch(`${API_BASE}/health`);
    const data = await res.json();
    box.textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    box.textContent = `Backend unavailable. Start Spring Boot on localhost:8080.

${error}`;
  }
}

async function loadClients() {
  const list = document.getElementById('client-list');
  if (!list) return;

  list.innerHTML = '<p class="muted">Loading clients...</p>';

  try {
    const res = await fetch(`${API_BASE}/clients`);
    const clients = await res.json();

    if (!Array.isArray(clients) || clients.length === 0) {
      list.innerHTML = '<p class="muted">No clients yet. Create your first one above.</p>';
      return;
    }

    list.innerHTML = clients.map(client => `
      <div class="client-item">
        <div>
          <strong>${client.name}</strong>
          <span class="muted">ID: ${client.id} · Tone: ${client.toneProfile} · Industry: ${client.industry || 'N/A'}</span>
        </div>
        <div class="action-row">
          <a class="btn secondary" href="client.html">Open Workspace</a>
          <a class="btn secondary" href="report.html">Open Report</a>
        </div>
      </div>
    `).join('');
  } catch (error) {
    list.innerHTML = `<p class="muted">Could not load clients. ${error}</p>`;
  }
}

async function createClient(event) {
  event.preventDefault();

  const payload = {
    name: document.getElementById('client-name').value,
    industry: document.getElementById('client-industry').value,
    toneProfile: document.getElementById('client-tone').value,
    timezone: 'UTC'
  };

  try {
    const res = await fetch(`${API_BASE}/clients`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    await res.json();
    event.target.reset();
    loadClients();
    alert('Client created successfully.');
  } catch (error) {
    alert(`Failed to create client: ${error}`);
  }
}

async function uploadCsv(event) {
  event.preventDefault();
  const clientId = document.getElementById('upload-client-id').value;
  const source = document.getElementById('upload-source').value;
  const fileInput = document.getElementById('upload-file');
  const resultBox = document.getElementById('upload-result');

  if (!fileInput.files.length) {
    resultBox.textContent = 'Please choose a CSV file.';
    return;
  }

  const formData = new FormData();
  formData.append('source', source);
  formData.append('file', fileInput.files[0]);

  try {
    const res = await fetch(`${API_BASE}/uploads/${clientId}`, {
      method: 'POST',
      body: formData
    });

    const data = await res.json();
    resultBox.textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    resultBox.textContent = `Upload failed: ${error}`;
  }
}

async function runAnalysis(event) {
  event.preventDefault();
  const clientId = document.getElementById('analysis-client-id').value;
  const start = document.getElementById('analysis-start').value;
  const end = document.getElementById('analysis-end').value;
  const resultBox = document.getElementById('analysis-result');

  try {
    const res = await fetch(`${API_BASE}/analysis/${clientId}?start=${start}&end=${end}`, {
      method: 'POST'
    });
    const data = await res.json();
    resultBox.textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    resultBox.textContent = `Analysis failed: ${error}`;
  }
}

async function generateReport(event) {
  event.preventDefault();
  const clientId = document.getElementById('report-client-id').value;
  const start = document.getElementById('report-start').value;
  const end = document.getElementById('report-end').value;
  const tone = document.getElementById('report-tone').value;

  try {
    const res = await fetch(`${API_BASE}/reports/${clientId}/generate?start=${start}&end=${end}&tone=${tone}`, {
      method: 'POST'
    });
    const data = await res.json();
    renderReport(data);
  } catch (error) {
    alert(`Report generation failed: ${error}`);
  }
}

async function getLatestReport() {
  const clientId = document.getElementById('report-client-id').value;
  if (!clientId) {
    alert('Enter a client ID first.');
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/reports/${clientId}/latest`);
    const data = await res.json();
    renderReport(data);
  } catch (error) {
    alert(`Loading latest report failed: ${error}`);
  }
}

function renderReport(data) {
  document.getElementById('report-summary').textContent = data.executiveSummary || 'No summary available.';
  document.getElementById('report-body').textContent = data.bodyMarkdown || 'No body content available.';
}
